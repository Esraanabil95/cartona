from odoo.tests.common import TransactionCase, HttpCase
import json

class TestSaleOrderAPI(HttpCase):

    def setUp(self):
        super(TestSaleOrderAPI, self).setUp()
        

        # Create test customer
        self.customer = self.env['res.partner'].create({
            'name': 'Test Customer',
            'email': 'test@example.com',
        })

        # Create test product
        self.product = self.env['product.product'].create({
            'name': 'Test Product',
            'lst_price': 100.0,
          '
        })

    def test_create_sale_order_success(self):
        """Test creating a sale order with valid data and valid token"""
        payload = {
            "customer": "Test Customer",
            "reference": "ref_3",
            "order_lines": [
                {"product": "Test Product", "quantity": 2, "price": 50}
            ]
        }

       headers = [
            ('Content-Type', 'application/json'),
            ('Authorization', request.httprequest.headers.get("Authorization")')
        ]

        response = self.url_open(
            '/api/create_sale_order',
            data=json.dumps(payload),
            headers=headers,
            method='POST'
        )

        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.text)

        self.assertTrue(response_data.get('success'))
        self.assertIn('order_id', response_data)
        self.assertIn('invoice_id', response_data)
        self.assertEqual(response_data['invoice_state'], 'draft')
        self.assertGreater(response_data['total_amount'], 0)

    def test_create_sale_order_invalid_token(self):
        """Test API with an invalid authentication token"""
        payload = {
            "customer": "Test Customer",
            "order_lines": [
                {"product": "Test Product", "quantity": 1, "price": 100}
            ]
        }

        headers = [
            ('Content-Type', 'application/json'),
            ('Authorization', 'invalid_token')
        ]

        response = self.url_open(
            '/api/create_sale_order',
            data=json.dumps(payload),
            headers=headers,
            method='POST'
        )

        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.text)
        self.assertIn('error', response_data)
        self.assertEqual(response_data['error'], 'Unauthorized')
